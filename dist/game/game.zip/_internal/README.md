A game with a level creator made by Kacper Kawecki
for a university course called Scripting Languages.

How to use:
Playing:
Launch app, press play, select a level.
Once the level is loaded jump through green platforms,|
avoid red obstacles and get to the blue objective.

Level creation:
Launch app, press level creator.
Drag objects from the bottom of the screen to add them,
right click to delete them. The game can only have one starting point.
Once you have created a level, write the name in the textbox in the bottom right and then press "save and quit".
The level will then be avalible in the level selector menu.